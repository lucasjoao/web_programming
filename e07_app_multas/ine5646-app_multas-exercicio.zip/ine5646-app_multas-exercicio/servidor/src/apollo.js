import { makeExecutableSchema } from 'graphql-tools'

import banco from './bancoMongoDB'

// The GraphQL schema in string form
const typeDefs = `
  type Query {
    proprietarios: [Proprietario]!,
    proprietario(cpf: ID!): Proprietario,
    veiculo(placa: ID!): Veiculo,
    veiculoComProprietario(placa: ID!): VeiculoComProprietario,
    veiculosDoProprietario(cpf: ID!): [Veiculo],
    multasDoVeiculo(placa: ID!): [Multa],
    multaCompleta(id: ID!): MultaCompleta
  }

  type Mutation {
    cadastraProprietario(cpf: ID!, nome: String!): Boolean!,
    cadastraProprietariosEmMassa(dados: [String]!): [String]!,
    cadastraVeiculo(cpf: ID!, placa: ID!, ano: Int!): CadastrouVeiculo!,
    cadastraVeiculosEmMassa(dados: [String]!): [String]!,
    cadastraMulta(placa: ID!, pontos: Int!): CadastrouMulta!,
    cadastraMultasEmMassa(dados: [String]!): [String]!
  }

  type Proprietario { cpf: ID!, nome: String! }
  type Veiculo { placa: ID!, ano: Int!, proprietario_cpf: ID!}
  type Multa { id: ID!, veiculo_placa: ID!, pontos: Int!}
  type MultaCompleta {id: ID!, pontos: Int!, placa: ID!, cpf: ID!, nome: String!}

  type CadastrouVeiculo {cadastrou: Boolean!, motivo: String}
  type CadastrouMulta {id: ID, motivo: String}
  type VeiculoComProprietario {veiculo: Veiculo!, proprietario: Proprietario!}
`

// The resolvers
const resolvers = {
  Query: {
    proprietarios: () => banco.proprietarios(),
    proprietario: (root, {cpf}) => banco.proprietario(cpf),
    veiculo: (root, {placa}) => banco.veiculo(placa),
    veiculoComProprietario: (root, {placa}) => banco.veiculoComProprietario(placa),
    veiculosDoProprietario: (root, {cpf}) => banco.veiculosDoProprietario(cpf),
    multasDoVeiculo: (root, {placa}) => banco.multasDoVeiculo(placa),
    multaCompleta: (root, {id}) => banco.multaCompleta(id)
  },

  Mutation: {
    cadastraProprietario: (root, {cpf, nome}) =>
      banco.cadastreProprietario(cpf, nome),

    cadastraProprietariosEmMassa: (root, {dados}) =>
      banco.cadastreProprietariosEmMassa(dados),

    cadastraVeiculosEmMassa: (root, {dados}) =>
      banco.cadastreVeiculosEmMassa(dados),

    cadastraMultasEmMassa: (root, {dados}) =>
      banco.cadastreMultasEmMassa(dados),

    cadastraVeiculo: (root, {cpf, placa, ano}) =>
      banco.cadastreVeiculo(cpf, placa, ano),

    cadastraMulta: (root, {placa, pontos}) =>
      banco.cadastreMulta(placa, pontos)
  }
}

// Put together a schema
const schema = makeExecutableSchema({
  typeDefs,
  resolvers
})

export {schema}
