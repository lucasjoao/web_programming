const util = {
  cpfMask : '999.999', // FIXME : provisório, só durante o desenvolvimento
  cpfTam : 6,
  placaMask : 'aaa-9999',
  placaTam : 7,
  anoMask : '9999',
  anoTam : 4,
  pontosMask : '99',
  pontosTam : 2,
  idMultaMask : '********',
  idMultaTam : 8
}

export default util
