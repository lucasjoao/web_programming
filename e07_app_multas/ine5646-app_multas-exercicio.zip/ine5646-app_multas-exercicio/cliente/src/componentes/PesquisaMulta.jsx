import React from 'react'
import PropTypes from 'prop-types'

import {DataTable} from 'primereact/components/datatable/DataTable'
import {Column} from 'primereact/components/column/Column'
import {Panel} from 'primereact/components/panel/Panel'
import {InputMask} from 'primereact/components/inputmask/InputMask'
import {Button} from 'primereact/components/button/Button'
import {Growl} from 'primereact/components/growl/Growl'
import {Card} from 'primereact/components/card/Card'

import servicos from '../servicos/servicos'
import util from '../util/util'

class PesquisaMulta extends React.Component {

  constructor() {
    super()
    this.state = {
      idMultaDefinido: false,
      idMulta: undefined,
      multa: undefined
    }
  }

  pesquise(ev) {
    ev.preventDefault() // evita envio de requisição ao servidor

    const prom = servicos.pesquiseMultaCompleta(this.state.idMulta)
    prom
      .then((multa) => {
        if (multa !== null) {
          this.setState({multa})
        } else {
          return Promise
            .reject(new Error(`Não existe multa com Id ${this.state.idMulta}`))
        }
      })
      .catch((erro) => {
        this.setState({multa: undefined})
        this.growl.show({
          severity: 'error',
          summary: 'Pesquisa por Multa',
          detail: erro.message})
      })
    this.setState({multa: undefined})
  }

  definiuId () {
    this.setState({idMultaDefinido : true})
  }

  armazeneId (ev) {
    if (ev.value !== this.state.idMulta) {
      this.setState({idMulta: ev.value, idMultaDefinido: false, multa: undefined})
    }
  }

  render() {
    let multa = null
    if (this.state.multa !== undefined)
      multa = this.__exibeMulta(this.state.multa)

    return (
      <Panel header='Pesquisar Multa'>
        <Growl ref={(el) => {this.growl = el}}/>
        <Card>
          <form onSubmit={this.pesquise.bind(this)}>
            <p>
              Id :
              <br/>
              <InputMask
                value={this.state.idMulta}
                onComplete={this.definiuId.bind(this)}
                onChange={this.armazeneId.bind(this)}
                mask={util.idMultaMask}
                unmask={true}
                size={util.idMultaMask.length}/>
            </p>
          </form>
          <Button
            label='Pesquisar'
            className='ui-button-success'
            type='submit'
            disabled={this.state.idMultaDefinido === false}
            onClick={this.pesquise.bind(this)}/>

          <Button
            label='Cancelar'
            className='ui-button-danger'
            onClick={this.props.cancelar}/>
        </Card>
        <div>{multa}</div>
      </Panel>
    )
  }

  __exibeMulta (multa) {
    return (
      <DataTable value={[multa]} className='ui-g'>
        <Column field='id' header='Id' className='ui-g-2 ui-sm-12'/>
        <Column field='pontos' header='Pontos' className='ui-g-1 ui-sm-12'/>
        <Column field='placa' header='Placa do Veículo' className='ui-g-1 ui-sm-12'/>
        <Column field='cpf' header='CPF do Proprietário' className='ui-g-2 ui-sm-12'/>
        <Column field='nome' header='Nome do Proprietário' className='ui-g-6 ui-sm-12'/>
      </DataTable>
    )
  }
}

PesquisaMulta.propTypes = {
  cancelar : PropTypes.func.isRequired
}

export default PesquisaMulta
