import React from 'react'
import PropTypes from 'prop-types'

import {Panel} from 'primereact/components/panel/Panel'
import {InputMask} from 'primereact/components/inputmask/InputMask'
import {Button} from 'primereact/components/button/Button'
import {Growl} from 'primereact/components/growl/Growl'

import servicos from '../servicos/servicos'
import util from '../util/util'

class CadastraMulta extends React.Component {

  constructor() {
    super()
    this.state = {
      placa : undefined,
      placaDefinida : false,
      pontos : undefined,
      pontosDefinidos: false
    }
  }

  naoPodeCadastrar () {
    return (!this.state.placaDefinida || !this.state.pontosDefinidos)
      ? 'disabeld' : 0
  }

  pesquiseVeiculo (placa) {
    servicos
      .pesquiseVeiculo(placa)
      .then((veiculo) => {
        if (veiculo === null) {
          this.growl.show({
            severity: 'warn',
            summary: 'Aviso',
            detail: `Placa ${placa} não cadastrada!`})
        } else {
          this.setState({placaDefinida: true, pontosDefinidos: false})
        }
      })
      .catch ((erro) => {
        this.growl.show({
          severity: 'error',
          summary: 'Erro',
          detail: erro.message
        })
      })
  }

  armazenePlaca (ev) {
    let placa = ev.value.toUpperCase()
    if (placa !== this.state.placa) {
      this.setState({placa: placa, placaDefinida: false})
      if (ev.value.length === util.placaTam)
        this.pesquiseVeiculo(placa)
    }
  }

  armazenePontos (ev) {
    if (ev.value !== this.state.pontos) {
      this.setState({pontos: ev.value, pontosDefinidos: false})
    }
  }

  pontosDefinidos () {
    this.setState({pontosDefinidos: true})
  }

  cadastre(ev) {
    ev.preventDefault() // evita envio de requisição ao servidor
    ev.persist()  // obrigatório por causa do ev.target abaixo

    servicos
      .cadastreMulta(this.state.placa, this.state.pontos)
      .then(({id, motivo}) => {
        if (id === null)
          return Promise.reject(new Error(motivo))

        ev.target.reset()
        this.setState({
          placa: undefined,
          placaDefinida: false,
          pontos: undefined,
          pontosDefinidos: false
        })
        this.growl.show({
          severity: 'success',
          summary: 'Cadastro de Multa',
          detail: `Multa cadastrada com ID ${id}`
        })
      })
      .catch((erro) => {
        this.growl.show({
          severity: 'error',
          summary: 'Cadastro de Multa',
          detail: erro.message
        })
      })
  }

  render() {
    return (
      <Panel header='Cadastrar Multa'>
        <Growl ref={(el) => {this.growl = el}}/>
        <form onSubmit={this.cadastre.bind(this)}>
          <p>
          Placa :
            <br/>
            <InputMask
              value={this.state.placa}
              onChange={this.armazenePlaca.bind(this)}
              mask={util.placaMask}
              unmask={true}
              size={util.placaMask.length}/>
          </p>
          <p>
          Pontos :
            <br/>
            <InputMask
              value={this.state.pontos}
              onChange={this.armazenePontos.bind(this)}
              onComplete={this.pontosDefinidos.bind(this)}
              mask={util.pontosMask}
              unmask={true}
              size={util.pontosMask.length}/>
          </p>
          <Button
            label='Cadastrar'
            className='ui-button-success'
            type='submit'
            disabled={this.naoPodeCadastrar.bind(this)()}/>
          <Button
            label='Cancelar'
            className='ui-button-danger'
            onClick={this.props.cancelar}/>
        </form>
      </Panel>
    )
  }
}

CadastraMulta.propTypes = {
  cancelar : PropTypes.func.isRequired
}

export default CadastraMulta
