import React from 'react'

import {Growl} from 'primereact/components/growl/Growl'
import {DataTable} from 'primereact/components/datatable/DataTable'
import {Column} from 'primereact/components/column/Column'

import PropTypes from 'prop-types'

import MostraVeiculos from './MostraVeiculos.jsx'

class MostraProprietarios extends React.Component {

  render() {
    return (
      <div>
        <Growl ref={(el) => {this.growl = el}}/>
        <DataTable value={this.props.proprietarios} className='ui-g'>
          <Column field='cpf' header='CPF' className='ui-g-1 ui-sm-12'/>
          <Column field='nome' header='Nome' className='ui-g-3 ui-sm-12'/>
          <Column
            header='Veículos'
            body={(p) => <MostraVeiculos cpf={p.cpf} ocultavel={true}/>}
            className='ui-g-8 ui-sm-12'/>
        </DataTable>

      </div>
    )
  }
}

MostraProprietarios.propTypes = {
  proprietarios : PropTypes.arrayOf(PropTypes.object).isRequired
}

export default MostraProprietarios
