import React from 'react'
import PropTypes from 'prop-types'

import {Panel} from 'primereact/components/panel/Panel'
import {InputMask} from 'primereact/components/inputmask/InputMask'
import {InputText} from 'primereact/components/inputtext/InputText'
import {Button} from 'primereact/components/button/Button'
import {Growl} from 'primereact/components/growl/Growl'

import servicos from '../servicos/servicos'
import util from '../util/util'

class CadastraProprietario extends React.Component {

  constructor() {
    super()
    this.state = {
      cpf : undefined,
      cpfDefinido : false,
      nome : undefined,
    }
  }

  naoPodeCadastrar () {
    if (this.state.cpfDefinido === false || this.state.nome === undefined || this.state.nome.trim() === '')
      return 'disabled'
    else
      return 0
  }

  definiuCPF () {
    this.setState({cpfDefinido : true})
  }

  armazeneCPF (ev) {
    if (ev.value !== this.state.cpf) {
      this.setState({cpf: ev.value, cpfDefinido: false})
    }
  }

  cadastre(ev) {
    ev.preventDefault() // evita envio de requisição ao servidor
    ev.persist()  // obrigatório por causa do ev.target abaixo

    const prom = servicos.cadastreProprietario(this.state.cpf, this.state.nome)
    prom
      .then((cadastrou) => {
        if (!cadastrou)
          return Promise.reject(new Error('Proprietário já cadastrado'))

        ev.target.reset()
        this.setState({nome: undefined, cpf: undefined, cpfDefinido: false})
        this.growl.show({
          severity: 'success',
          summary: 'Cadastro de Proprietário',
          detail: 'Cadastro feito!'})
      })
      .catch((erro) => {
        this.growl.show({
          severity: 'error',
          summary: 'Cadastro de Proprietário',
          detail: erro.message})
      })
  }

  render() {
    return (
      <Panel header='Cadastrar Proprietário'>
        <Growl ref={(el) => {this.growl = el}}/>
        <form onSubmit={this.cadastre.bind(this)}>
          <p>
          CPF :
            <br/>
            <InputMask
              value={this.state.cpf}
              onComplete={this.definiuCPF.bind(this)}
              onChange={this.armazeneCPF.bind(this)}
              mask={util.cpfMask}
              unmask={true}
              size={util.cpfMask.length}/>
          </p>
          <p>
          Nome :
            <br/>
            <InputText
              type='text'
              onChange={(ev) => this.setState({nome: ev.target.value})}
              size='30'/>
          </p>
          <Button
            label='Cadastrar'
            className='ui-button-success'
            type='submit'
            disabled={this.naoPodeCadastrar.bind(this)()}/>
          <Button
            label='Cancelar'
            className='ui-button-danger'
            onClick={this.props.cancelar}/>
        </form>
      </Panel>
    )
  }
}

CadastraProprietario.propTypes = {
  cancelar : PropTypes.func.isRequired
}

export default CadastraProprietario
