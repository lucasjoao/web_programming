import React from 'react'
import PropTypes from 'prop-types'

import {Panel} from 'primereact/components/panel/Panel'
import {InputMask} from 'primereact/components/inputmask/InputMask'
import {Button} from 'primereact/components/button/Button'
import {Growl} from 'primereact/components/growl/Growl'
import {Card} from 'primereact/components/card/Card'

import servicos from '../servicos/servicos'
import util from '../util/util'
import MostraProprietarios from './MostraProprietarios.jsx'

class PesquisaProprietario extends React.Component {

  constructor() {
    super()
    this.state = {
      cpfDefinido: false,
      cpf: undefined,
      proprietario: undefined
    }
  }

  pesquise(ev) {
    ev.preventDefault() // evita envio de requisição ao servidor

    const prom = servicos.pesquiseProprietario(this.state.cpf)
    prom
      .then((proprietario) => {
        if (proprietario !== null) {
          this.setState({proprietario})
          this.growl.show({
            severity: 'success',
            summary: 'Pesquisa por Proprietário',
            detail: 'Proprietário encontrado!'})
        } else {
          return Promise.reject(new Error(`Não existe proprietário com CPF ${this.state.cpf}`))
        }
      })
      .catch((erro) => {
        this.setState({proprietario: undefined})
        this.growl.show({
          severity: 'error',
          summary: 'Pesquisa por Proprietário',
          detail: erro.message})
      })
    this.setState({proprietario: undefined})
  }

  definiuCPF () {
    this.setState({cpfDefinido : true})
  }

  armazeneCPF (ev) {
    if (ev.value !== this.state.cpf) {
      this.setState({cpf: ev.value, cpfDefinido: false, proprietario: undefined})
    }
  }

  render() {
    let proprietario = null
    if (this.state.proprietario !== undefined)
      proprietario = <MostraProprietarios proprietarios={[this.state.proprietario]}/>

    return (
      <Panel header='Pesquisar Proprietário'>
        <Growl ref={(el) => {this.growl = el}}/>
        <Card>
          <form onSubmit={this.pesquise.bind(this)}>
            <p>
              CPF :
              <br/>
              <InputMask
                value={this.state.cpf}
                onComplete={this.definiuCPF.bind(this)}
                onChange={this.armazeneCPF.bind(this)}
                mask={util.cpfMask}
                unmask={true}
                size={util.cpfMask.length}/>
            </p>
          </form>
          <Button
            label='Pesquisar'
            className='ui-button-success'
            type='submit'
            disabled={this.state.cpfDefinido === false}
            onClick={this.pesquise.bind(this)}/>

          <Button
            label='Cancelar'
            className='ui-button-danger'
            onClick={this.props.cancelar}/>
        </Card>
        <div>{proprietario}</div>
      </Panel>
    )
  }
}

PesquisaProprietario.propTypes = {
  cancelar : PropTypes.func.isRequired
}

export default PesquisaProprietario
