import React from 'react'
import PropTypes from 'prop-types'

import {Panel} from 'primereact/components/panel/Panel'
import {InputMask} from 'primereact/components/inputmask/InputMask'
import {Button} from 'primereact/components/button/Button'
import {Growl} from 'primereact/components/growl/Growl'
import {Card} from 'primereact/components/card/Card'

import servicos from '../servicos/servicos'
import util from '../util/util'
import MostraVeiculos from './MostraVeiculos.jsx'

class PesquisaVeiculo extends React.Component {

  constructor() {
    super()
    this.state = {
      placaDefinida: false,
      placa: undefined,
      veiculoComProprietario: undefined
    }
  }

  pesquise(ev) {
    ev.preventDefault() // evita envio de requisição ao servidor

    const prom = servicos.pesquiseVeiculoComProprietario(this.state.placa)
    prom
      .then((veiculoComProprietario) => {
        if (veiculoComProprietario !== null) {
          this.setState({veiculoComProprietario})
          this.growl.show({
            severity: 'success',
            summary: 'Pesquisa por Veículo',
            detail: 'Veículo encontrado!'})
        } else {
          return Promise.reject(new Error(`Não existe veículo com placa ${this.state.placa}`))
        }
      })
      .catch((erro) => {
        this.setState({veiculoComProprietario: undefined})
        this.growl.show({
          severity: 'error',
          summary: 'Pesquisa por Veículo',
          detail: erro.message})
      })
    this.setState({veiculoComProprietario: undefined})
  }

  definiuPlaca () {
    this.setState({placaDefinida : true})
  }

  armazenePlaca (ev) {
    if (ev.value !== this.state.placa) {
      this.setState({
        placa: ev.value,
        placaDefinida: false,
        veiculoComProprietario: undefined
      })
    }
  }

  render() {
    let veiculo = null
    if (this.state.veiculoComProprietario !== undefined) {
      const p = this.state.veiculoComProprietario.proprietario
      const v = this.state.veiculoComProprietario.veiculo
      const titulo = `Proprietário CPF ${p.cpf} Nome: ${p.nome}`
      veiculo =
        <Panel header={titulo}>
          <MostraVeiculos
            cpf={p.cpf}
            ocultavel={false}
            veiculos={[v]}/>
        </Panel>
    }
    return (
      <Panel header='Pesquisar Veículo'>
        <Growl ref={(el) => {this.growl = el}}/>
        <Card>
          <form onSubmit={this.pesquise.bind(this)}>
            <p>
              Placa :
              <br/>
              <InputMask
                value={this.state.placa}
                onComplete={this.definiuPlaca.bind(this)}
                onChange={this.armazenePlaca.bind(this)}
                mask={util.placaMask}
                unmask={true}
                size={util.placaMask.length}/>
            </p>
          </form>
          <Button
            label='Pesquisar'
            className='ui-button-success'
            type='submit'
            disabled={this.state.placaDefinida === false}
            onClick={this.pesquise.bind(this)}/>

          <Button
            label='Cancelar'
            className='ui-button-danger'
            onClick={this.props.cancelar}/>
        </Card>
        <div>{veiculo}</div>
      </Panel>
    )
  }
}

PesquisaVeiculo.propTypes = {
  cancelar : PropTypes.func.isRequired
}

export default PesquisaVeiculo
