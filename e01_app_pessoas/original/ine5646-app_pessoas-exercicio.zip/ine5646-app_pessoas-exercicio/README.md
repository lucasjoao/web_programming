# app_pessoas

Exercício simples que mostra uma página 100% gerada no lado servidor.