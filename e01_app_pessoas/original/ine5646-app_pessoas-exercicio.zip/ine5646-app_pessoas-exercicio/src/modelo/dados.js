import {Pessoa} from './pessoa'

const pessoas =
  [ new Pessoa('Marcolino da Silva', 45),
    new Pessoa('Tribulino Garrteto', 25),
    new Pessoa('Burico do Pino Solto', 35)
  ]

const idadeMinima = 30

export {pessoas, idadeMinima}
