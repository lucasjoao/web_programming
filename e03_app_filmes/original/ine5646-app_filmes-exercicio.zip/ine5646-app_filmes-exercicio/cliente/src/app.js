import React from 'react'
import ReactDOM from 'react-dom'
import {IU} from './visao/IU.jsx'

ReactDOM.render(<IU/>, document.getElementById('app'))
