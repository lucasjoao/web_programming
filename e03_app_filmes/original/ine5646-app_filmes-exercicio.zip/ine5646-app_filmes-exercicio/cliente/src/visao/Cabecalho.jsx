import React from 'react'

class Cabecalho extends React.Component {
  render () {
    return (
      <div className="message">
        <div className="message-header">
          <p>UFSC - CTC - INE - INE5646 - App Filmes</p>
        </div>
      </div>
    )
  }
}

export {
  Cabecalho
}
