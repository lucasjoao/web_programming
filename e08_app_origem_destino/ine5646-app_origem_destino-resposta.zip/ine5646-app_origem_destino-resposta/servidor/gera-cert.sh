openssl req -x509 -days 365 -nodes -newkey rsa:1024 -keyout key.pem -out cert.pem
