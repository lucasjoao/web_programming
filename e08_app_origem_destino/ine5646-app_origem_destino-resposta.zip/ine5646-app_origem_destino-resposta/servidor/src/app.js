import express from 'express'
import fs from 'fs'
import https from 'https'
import http from 'http'
import path from 'path'

import fetch from 'node-fetch'

import pesquisador from './pesquisador'

import helmet from 'helmet'

const PORTA_HTTPS = 3001
const PORTA_HTTP = 3004
const msgHTTPS = `Servidor HTTPS no ar, porta ${PORTA_HTTPS}`
const msgHTTP = `Requisições HTTP porta ${PORTA_HTTP} são redirecionadas para HTTPS`

const app = express()

// Redireciona requisições HTTP para HTTPS
app.use((req, res, next) => {
  if (!req.secure) {
    const urlSegura = `https://${req.hostname}:${PORTA_HTTPS}${req.originalUrl}`
    res.redirect(urlSegura)
  } else {
    next()
  }
})

// Insere cabeçalhos de segurança
app.use(helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: [
      "'self'",
      "https://apis.google.com",
      "https://accounts.google.com",
      "https://*.googleusercontent.com"
    ],
  }
}))

// Localização de conteúdo estático (index.html, CSS, JavaScript, etc)
app.use(express.static(path.join(__dirname, 'publico')))

app.get("/pesquise", (req, res) => {
    const origem = req.query.origem
    const destino = req.query.destino
    pesquisador
      .pesquise(origem, destino)
      .then(resposta => res.json(resposta))
})


// ------- Para colocar o servidor no ar -------

const key_cert = {
  key: fs.readFileSync(path.join(__dirname, 'key.pem')),
  cert: fs.readFileSync(path.join(__dirname, 'cert.pem'))
}

https
  .createServer(key_cert, app)
  .listen(PORTA_HTTPS, () => console.log(msgHTTPS))

http
  .createServer(app)
  .listen(PORTA_HTTP, () => console.log(msgHTTP))
