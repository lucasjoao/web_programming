import fetch from 'node-fetch'
import encodeurl from 'encodeurl'

const urlBase = 'https://maps.googleapis.com/maps/api/distancematrix/json'

//definida em https://console.developers.google.com
const apiKey = 'substitua pela sua API Key'

const pesquisador = {
  pesquise: async (origem, destino) => {
    const parametros = `origins=${origem}&destinations=${destino}&key=${apiKey}&language=pt-BR`
    const urlPesquisa = encodeurl(`${urlBase}?${parametros}`)
    let resposta
    try {
      const r1 = await fetch(urlPesquisa)
      const r = await r1
      const json = await r.json()
      resposta = await analiseResposta(json)
    } catch (erro) {
      resposta = await monteRespostaErro(erro.message)
    }
    return resposta
  }
}

async function monteRespostaErro(msgDeErro) {
  return {erro: msgDeErro}
}


async function analiseResposta(jsonGoogle) {
  let resposta = {}

  if (jsonGoogle.status !== 'OK')
    resposta = monteRespostaErro('Serviço indisponível no momento.')
  else {
    if (jsonGoogle.rows[0].elements[0].status !== 'OK')
      resposta = monteRespostaErro('Não é possível determinar distância e tempo')
    else {
      resposta.origem = jsonGoogle.origin_addresses[0]
      resposta.destino = jsonGoogle.destination_addresses[0]
      resposta.distancia = jsonGoogle.rows[0].elements[0].distance.text
      resposta.tempo = jsonGoogle.rows[0].elements[0].duration.text
    }
  }
  return resposta
}

export default pesquisador
