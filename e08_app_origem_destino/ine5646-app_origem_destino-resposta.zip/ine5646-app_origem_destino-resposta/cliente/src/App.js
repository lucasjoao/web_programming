import React, {Component} from 'react';
import dadosOAuth2 from './util/dadosOAuth2'

import Container from './componentes/bulma/Container.jsx'
import Message from './componentes/bulma/Message.jsx'
import Notification from './componentes/bulma/Notification.jsx'

import Usuario from './componentes/Usuario.jsx'
import PainelOrigemDestino from './componentes/PainelOrigemDestino.jsx'

class App extends Component {
  constructor() {
    super()
    this.estadoDoLogin = {
      NAO: 0,
      FAZENDO: 1,
      SIM: 2
    }
    this.facaLogin = this.facaLogin.bind(this)
    this.facaLogout = this.facaLogout.bind(this)
    this.atualizeStatusLogado = this.atualizeStatusLogado.bind(this)

    this.state = {
      gapiPronto: false,
      login: this.estadoDoLogin.NAO,
      GoogleAuth: undefined,
      user: undefined
    }
  }

  componentDidMount() {
    this.props.gapi.load('client:auth2', () => {
      this.props.gapi.client.init(dadosOAuth2).then(() => {
        const GoogleAuth = this.props.gapi.auth2.getAuthInstance()
        GoogleAuth.isSignedIn.listen(this.atualizeStatusLogado)
        GoogleAuth.disconnect()
        this.setState({GoogleAuth, gapiPronto: true})
      })
    })
  }

  atualizeStatusLogado(estaLogado) {
    if (estaLogado) {
      const user = this.state.GoogleAuth.currentUser.get()
      const autorizou = user.hasGrantedScopes(dadosOAuth2.scope)
      if (autorizou)
        this.setState({user, login: this.estadoDoLogin.SIM})
      else
        this.setState({user: undefined, login: this.estadoDoLogin.NAO})
    }
    else
      this.setState({user: undefined, login: this.estadoDoLogin.NAO})

  }

  facaLogin() {
    this.state.GoogleAuth.signIn()
    this.setState({login: this.estadoDoLogin.FAZENDO})
  }

  facaLogout() {
    this.state.GoogleAuth.disconnect()
  }

  render() {
    if (!this.state.gapiPronto)
      return <p>Carregando...</p>

    let botao
    let conteudo

    switch (this.state.login) {
      case this.estadoDoLogin.SIM: {
        botao =  <button className='button is-primary' onClick={this.facaLogout}>Sair</button>
        conteudo = <div>
          <Usuario nome={this.state.user.w3.ig} img={this.state.user.w3.Paa}/>
          <PainelOrigemDestino/>
        </div>
        break
      }
      case this.estadoDoLogin.NAO:
        botao = <button className='button is-primary' onClick={this.facaLogin}>Entrar</button>
        break
      case this.estadoDoLogin.FAZENDO:
        botao = <Notification>Aguardando login em outra janela...</Notification>
        break
      default:
        botao = <h2>Erro inesperado do programa</h2>
    }
    return (
      <Container>
        <Message cabecalho='INE5646 - App Origem-Destino'>
          {conteudo}
          {botao}
        </Message>
      </Container>)
  }
}

export default App;
