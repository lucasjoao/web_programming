// Dados OAuth2 usados pela aplicação.

const dadosOAuth2 = {
  apiKey: 'substitua pela sua API Key',
  clientId: 'complete com seu clienteId.apps.googleusercontent.com',
  scope: 'email openid',
  discoveryDocs: []
}

export default dadosOAuth2
