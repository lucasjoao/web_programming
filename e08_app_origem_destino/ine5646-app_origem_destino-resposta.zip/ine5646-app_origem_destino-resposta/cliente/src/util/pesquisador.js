
const urlBase = '/pesquise'

const pesquisador = {
  pesquise: (origem, destino) => {
    const parametros = `origem=${origem}&destino=${destino}`
    const urlPesquisa = encodeURI(`${urlBase}?${parametros}`)
    return fetch(urlPesquisa)
      .then(r => Promise.resolve(r))
      .then(r => r.json())
      .catch(erro => Promise.resolve({erro: 'Servidor fora do ar...'}))
  }
}

export default pesquisador
