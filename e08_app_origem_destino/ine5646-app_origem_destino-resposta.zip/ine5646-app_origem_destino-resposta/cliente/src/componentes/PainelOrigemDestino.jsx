import React from 'react'
import pesquisador from '../util/pesquisador'
import Message from './bulma/Message.jsx'
import FormField from './bulma/FormField.jsx'
import Information from './bulma/Information.jsx'

class PainelOrigemDestino extends React.Component {
  constructor() {
    super()
    this.state = {
      origem: '',
      destino: '',
      origemEncontrada: undefined,
      destinoEncontrado: undefined,
      distancia: undefined,
      tempo: undefined,
      pesquisando: false,
      erro: undefined
    }

    this.altereOrigem = this.altereOrigem.bind(this)
    this.altereDestino = this.altereDestino.bind(this)
    this.podePesquisar = this.podePesquisar.bind(this)
    this.pesquise = this.pesquise.bind(this)
  }

  altereOrigem(ev) {
    this.setState({
      origem: ev.target.value,
      pesquisando: false,
      origemEncontrada: undefined,
      destinoEncontrado: undefined,
      tempo: undefined,
      distancia: undefined,
      erro: undefined
    })
  }

  altereDestino(ev) {
    this.setState({
      destino: ev.target.value,
      pesquisando: false,
      origemEncontrada: undefined,
      destinoEncontrado: undefined,
      tempo: undefined,
      distancia: undefined,
      erro: undefined
    })
  }

  podePesquisar() {
    const pode = this.state.origem.trim().length > 0 && this.state.destino.trim().length > 0 && !this.state.pesquisando
    return pode
      ? null
      : 'disabled'
  }

  pesquise() {
    pesquisador
      .pesquise(this.state.origem, this.state.destino)
      .then(resposta => {
        if (resposta.erro !== undefined)
          this.setState({pesquisando: false, erro: resposta.erro})
        else {
          const {origem, destino, distancia, tempo} = resposta

          const novoEstado = {
            origemEncontrada: origem,
            destinoEncontrado: destino,
            distancia,
            tempo,
            erro: undefined,
            pesquisando: false
          }
          this.setState(novoEstado)
        }
      })
      .catch(erro => this.setState({erro: 'Sistema indisponível'}))
    this.setState({pesquisando: true, erro: undefined})
  }

  render() {
    let resposta
    if (this.state.erro !== undefined)
      resposta = <Message cabecalho='Resultado' tipo='is-danger'>{this.state.erro}</Message>
    else
      if (this.state.origemEncontrada !== undefined)
        resposta =
        <Message cabecalho='Resultado' tipo='is-success'>
          <Information label='Origem Encontrada' info={this.state.origemEncontrada}/>
          <Information label='Destino Encontrado' info={this.state.destinoEncontrado}/>
          <Information label='Distância' info={this.state.distancia}/>
          <Information label='Tempo de Viagem' info={this.state.tempo}/>
      </Message>

    return (
      <Message cabecalho='Pesquisar Distância e Tempo de Viagem' tipo='is-link'>
        <FormField
          label='Cidade de Origem'
          value={this.state.origem}
          onChange={this.altereOrigem}/>
        <FormField
          label='Cidade de Destino'
          value={this.state.destino}
          onChange={this.altereDestino}/>

        <button
          className='button is-primary'
          onClick={this.pesquise}
          disabled={this.podePesquisar()}>
            Pesquisar
        </button>
        {resposta}
    </Message>
  )
  }
}

export default PainelOrigemDestino
