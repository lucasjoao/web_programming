import React from 'react'
import Message from './bulma/Message.jsx'

const Usuario = (props) => {
  const nome = `Usuário: ${props.nome}`
  return (
    <Message cabecalho={nome} tipo='is-info'>
      <img src={props.img} alt='Foto do usuário'/>
    </Message>
  )
}

export default Usuario
