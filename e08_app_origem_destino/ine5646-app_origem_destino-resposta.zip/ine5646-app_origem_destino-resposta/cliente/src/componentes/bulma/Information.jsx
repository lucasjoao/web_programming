import React from 'react'

const Information = (props) => {
  return (
    <div className='field'>
      <label className='label'>{props.label}</label>
      <div className='control'>
        {props.info}
      </div>
    </div>
  )
}

export default Information
