import React from 'react'

const FormField = (props) => {
  return (
    <div className="field">
      <label className="label">{props.label}</label>
      <div className="control">
        <input className="input"
          type="text"
          value={props.value}
          onChange={props.onChange}/>
      </div>
    </div>
    )
}

export default FormField
