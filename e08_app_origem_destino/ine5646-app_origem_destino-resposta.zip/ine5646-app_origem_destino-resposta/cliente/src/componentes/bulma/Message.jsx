import React from 'react'

const Message = (props) => {
  const tipoMsg = `message ${props.tipo}`
    return (
      <div className={tipoMsg}>
        <div className='message-header'>
          {props.cabecalho}
        </div>
        <div className='message-body'>
          {props.children}
        </div>
      </div>
    )
}

export default Message
