import React from 'react'

const Notification = (props) => {

  return (
    <div className='notification is-primary'>
      {props.children}
    </div>
  )
}

export default Notification
